function x0 = robotInitialConditions(param)

x0 = [0;0;0;0;0];