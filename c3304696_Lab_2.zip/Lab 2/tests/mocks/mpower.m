function C = mpower(A,B)

error('Don''t raise a matrix to a power in robotMomentum()');
