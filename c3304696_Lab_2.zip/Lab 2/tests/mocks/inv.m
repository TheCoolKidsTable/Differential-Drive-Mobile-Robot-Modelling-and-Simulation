function Y = inv(X)

error('Don''t use inv() in robotMomentum()');
