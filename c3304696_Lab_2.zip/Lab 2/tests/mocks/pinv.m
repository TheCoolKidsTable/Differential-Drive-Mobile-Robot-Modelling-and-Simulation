function Y = pinv(A,tol)

error('Don''t use pinv() in robotMomentum()');
